# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex6.py - Jython implementation of example script 6
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the invocation  
#  of some commands that produce a short summary of some configuration
#  and runtime information about the WebSphere installation. 
#  
#  This script it can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex6.py all
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex6.py") or execfile("ex6.py")
#     wsadmin> ex6("all")
#
#  The script expects one parameter:
#      arg1 - a flag -- either "all" or "config" 
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminControl object to locate running MBeans 
#   - The use of the AdminControl object to getAttributes from running MBeans 
#   - The use of the AdminControl object to invoke operations on running MBeans 
#   - The use of the AdminConfig  object to locate configuration objects        
#   - The use of the AdminConfig  object to display attributes of configuration objects        
#   - The use of the AdminConfig getObjectName command to look up a running object.
#   - The use of the AdminControl getConfigId  command to look up a config object.
#-----------------------------------------------------------------
#
import sys, java

lineSeparator = java.lang.System.getProperty('line.separator')

def ex6(flag):
   if (flag == "config"):
      configOnly = 1
   elif (flag == "all"):
      configOnly = 0
   else:
      print 'Single argument must be "all" or "config"'
      return
  
   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminControl
   global AdminConfig
   global AdminApp


   print "Installation summary: "           
   print "----------------------------------------------------"           
   print ""

   #---------------------------------------------------------
   # Get the cells/nodes/servers 
   #---------------------------------------------------------
   print "Configured cells, nodes, and servers: "           
   print "----------------------------------------------------"           
   print ""
   cells = AdminConfig.list("Cell").split(lineSeparator)
   print "Number of cells: %s" % (len(cells))

   for cell in cells:

      #---------------------------------------------------------
      # Get some attributes from the config for this cell --
      # the name and the security enabled flag. 
      #---------------------------------------------------------
      cname = AdminConfig.showAttribute(cell, "name")
      sec = AdminConfig.list("Security", cell)
      enabled = AdminConfig.showAttribute(sec, "enabled")
      print cname + "-- security enabled: " + enabled

      #---------------------------------------------------------
      # Get a list of the nodes in this cell, and the name of each
      #---------------------------------------------------------
      nodes = AdminConfig.list("Node", cell)
      if len(nodes) == 0:
         print "  There is no node in " + cname
         continue

      nodesList = nodes.split(lineSeparator)
      print "  Number of nodes in %s: %s" % (cname, len(nodesList)) 
      for node in nodesList:
         nname = AdminConfig.showAttribute(node, "name")
         print "  " + nname

         #---------------------------------------------------------
         # Get a list of the servers on this node.  Use getObjectName
         # to see if there is a running server for this config object. 
         #---------------------------------------------------------
         servers = AdminConfig.list("Server", node)
         if len(servers) == 0:
            print "    There is no server on " + nnmae
            continue

         serversList = servers.split(lineSeparator)
         print "    Number of servers in " + nname + ": %s" % (len(serversList))
         for server in serversList:
            print ""
            sname = AdminConfig.showAttribute(server, "name")
            runserv = AdminConfig.getObjectName(server)
            if len(runserv) > 0:
               state = AdminControl.getAttribute(runserv, "state")
               print "    Server " + sname + " is running: state is " + state
            else:
               print "    Server " + sname + " is not running"

            #---------------------------------------------------------
            # Get a list of the http transports on the server, and display 
            # host and port information for them. 
            #---------------------------------------------------------
            https = AdminConfig.list("HTTPTransport", server)
            if len(https) == 0:
               print "      There is no HTTP transport on " + sname
               continue

            httpsList = https.split(lineSeparator)
            print "       " + sname + " has %s HTTP transports" % (len(httpsList))
            for http in httpsList:
               addr = AdminConfig.showAttribute(http, "address")
               host = AdminConfig.showAttribute(addr, "host")
               port = AdminConfig.showAttribute(addr, "port")
               print "         port: " + port + " on host " + host
            print ""
         print "" 


      #---------------------------------------------------------
      # Get a list of the ServerClusters and display it. 
      #---------------------------------------------------------
      print "" 
      clusters = AdminConfig.list("ServerCluster", cell)
      if len(clusters) == 0:
         print "  There is no clusters on " + cname
         continue

      clustersList = clusters.split(lineSeparator)
      print "  Number of clusters in " + cname + ": %s" % (len(clustersList))
      for cluster in clustersList:
         clname = AdminConfig.showAttribute(cluster, "name")
         memberList = AdminConfig.showAttribute(cluster, "members")
         if len(memberList) > 0:
            members = memberList[1:len(memberList)-1].split(" ")
            print "  Cluster " + clname + " has %s members" % (len(members))
            for member in members:
               mname = AdminConfig.showAttribute(member, "memberName")
               weight = AdminConfig.showAttribute(member, "weight")
               print "    Member " + mname + " has weight " + weight
         print ""


   #---------------------------------------------------------
   # Get the apps 
   #---------------------------------------------------------
   print "----------------------------------------------------"           
   print ""
   apps = AdminApp.list()
   if len(apps) == 0:
      print "There is no application"
   else:
      appsList = apps.split(lineSeparator)
      print "Number of applications: %s" % (len(appsList))
      print ""
      for app in appsList:
         print app
 
   if configOnly == 1:
      return

   #---------------------------------------------------------
   # What servers are running on each node, and what apps do they have? 
   #---------------------------------------------------------
   print ""
   print "Running servers: "           
   print "----------------------------------------------------"           
   print ""
   for cell in cells:
      cname = AdminConfig.showAttribute(cell, "name")
      nodes = AdminConfig.list("Node", cell)
      if len(nodes) == 0:
         print "There is no node on " + cname
         continue

      nodesList = nodes.split(lineSeparator)
      for node in nodesList:
         nname = AdminConfig.showAttribute(node, "name")
         servers = AdminControl.queryNames("type=Server,cell=" + cname + ",node=" + nname + ",*")
         if len(servers) == 0:
            print "There is no running server on node " + nname
            continue

         serversList = servers.split(lineSeparator)
         print "Number of running servers on node %s: %s" % (nname, len(serversList))
         for server in serversList:

            #---------------------------------------------------------
            # Get some attributes from the server to display; also invoke 
            # an operation on the server JVM to display a property.  
            #---------------------------------------------------------
            sname = AdminControl.getAttribute(server, "name")
            ptype = AdminControl.getAttribute(server, "processType")
            pid = AdminControl.getAttribute(server, "pid")
            state = AdminControl.getAttribute(server, "state")
            jvm = AdminControl.queryNames("type=JVM,cell=" + cname + ",node=" + nname + ",process=" + sname + ",*")
            osname  = AdminControl.invoke(jvm, "getProperty", "os.name")
            print "  %s (%s) has pid %s; state: %s; on %s" % (sname, ptype, pid, state, osname)
 
            #---------------------------------------------------------
            # Use getConfigId to see if there is config data for this 
            # server.
            #---------------------------------------------------------
            configserv = AdminControl.getConfigId(server)
            if len(configserv) > 0:
               print "  %s is configured." % (sname)
            else:
               print "  %s is not configured; configuration must have changed after the server was started." % (sname)

            #---------------------------------------------------------
            # Find the applications running on this server. 
            #---------------------------------------------------------
            apps = AdminControl.queryNames("type=Application,cell=" + cname + ",node=" + nname + ",process=" + sname + ",*")
            if len(apps) == 0:
               print "  There is no applications running on " + sname
            else:
               appsList = apps.split(lineSeparator)
               print "  Number of applications running on %s: %s" % (sname, len(appsList))
               for app in appsList:
                  aname = AdminControl.getAttribute(app, "name")
                  print "    %s" % (aname)
            print "----------------------------------------------------"
            print ""
 
            #---------------------------------------------------------
            # Display the serverVersion information. 
            #---------------------------------------------------------
            svreport = AdminControl.getAttribute(server, "serverVersion")
            print "Server version report for this server follows:"
            print "  %s" % (svreport)
            print "----------------------------------------------------"           
            print ""
 

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv)) != 1:
   print 'ex6: this script requires 1 parameter: a flag that should be "all" or "config"'
   print ""
   print "e.g.:     ex6  all" 
else:
   ex6(sys.argv[0])
