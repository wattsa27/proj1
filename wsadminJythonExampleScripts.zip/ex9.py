# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex9.py - Jython implementation of example script 9
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the creation of a 
#  JDBCProvider, DataSource and CMPConnectorFactory objects.
#  
#  This script can be included in the wsadmin command invocation like this:
#  
#     wsadmin -lang jython -f ex9.py mynode "DB2 Universal JDBC Driver Provider (XA)" myjdbc myds mycf sampleDB
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex9.py") or execfile("ex9.py")
#     wsadmin> ex9("mynode", "DB2 Universal JDBC Driver Provider (XA)", "myjdbc", "myds", "mycf", "sampleDB")
#
#  The script expects 6 parameters:
#    node name
#    template name for JDBCProvider 
#    jdbc provider name to be created
#    datasource name to be created
#    CMP Connection factory name to be created
#    name of database 
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminConfig object to locate configuration objects        
#   - The use of the AdminConfig object to modify configuration objects
#   - The use of the AdminConfig object to create configuration objects 
#   - The use of the AdminConfig object to remove configuration objects 
#-----------------------------------------------------------------
#
import sys, java
lineSeparator = java.lang.System.getProperty('line.separator')

def ex9(nodeName, templateName, jdbcname, dsname, cfname, dbname):
  
   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig

   CONT_ALIAS = "my-containerAuth-Alias"
   DEFAULT_PRINCIPAL_MAPPING = "DefaultPrincipalMapping"

   #---------------------------------------------------------
   # Get the config id for a JDBC Template
   # Use "lindex" in case there is more than one matching templates -- we
   # just get the first one. 
   #---------------------------------------------------------
   print "ex9: getting the JDBCProvider template whose name is " +  templateName
   template = AdminConfig.listTemplates("JDBCProvider", templateName).split(lineSeparator)[0]
   if len(template) == 0:
      print "ex9: could not find a JDBCProvider template using " + templateName
      return
 
   #---------------------------------------------------------
   # Get the config id for the node 
   #---------------------------------------------------------
   print "ex9: getting the confid id for node " + nodeName 
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   if len(node) == 0:
      print "ex9: could not find node " + nodeName
      return
 
   #---------------------------------------------------------
   # Create a new JDBCProvider using this template 
   #---------------------------------------------------------
   print "ex9: create a new JDBCProvider object named " + jdbcname
   nameAttr = ["name", jdbcname]
   attrs = []
   attrs.append(nameAttr)
   new1 = AdminConfig.createUsingTemplate("JDBCProvider", node, attrs, template)
 
   #---------------------------------------------------------
   # For this example, we do not need the WAS40DataSource object, but
   # we do want to modify the DataSource object. 
   # Note that the template for this JDBCProvider does not give
   # names to the WAS40DataSource and DataSource objects associated with
   # it.  We can use "getid" to retrieve ids for objects that do not have
   # names as shown below.
   #---------------------------------------------------------
   print "ex9: remove the WAS40DataSource object created via the template"
   was40ds = AdminConfig.getid("/JDBCProvider:" + jdbcname + "/WAS40DataSource:/")
   AdminConfig.remove(was40ds)
    
   #--------------------------------------------------------------
   # Modify the DataSource - give it a name and a jndiName, and remove 
   # existing properties created by the template
   # A collection of objects (such as the resourceProperties attribute of the
   # propertySet attribute) can only be added to.  To completely replace
   # the collection you need to delete the old one first.
   #--------------------------------------------------------------
   print "ex9: modify the datasource object -- name, jndiName; remove old properties."
   ds = AdminConfig.getid("/JDBCProvider:" + jdbcname + "/DataSource:/")
   nameAttr = ["name", dsname]
   jndiNameAttr = ["jndiName", "jdbc/" + dsname]
   psAttr = ["propertySet", []]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(jndiNameAttr)
   attrs.append(psAttr)
   AdminConfig.modify(ds, attrs)
    
   #--------------------------------------------------------------
   # Add desired properties to the DataSource.
   #--------------------------------------------------------------
   print "ex9: modify the datasource object -- name, jndiName, properties."
   dbnameAttr = [["name", "databaseName"], ["value", dbname], ["type", "java.lang.String"], ["description", "This is a required property"]]
   descAttr = [["name", "description"], ["value", ""], ["type", "java.lang.String"]] 
   passwordAttr = [["name", "password"], ["value", ""], ["type", "java.lang.String"]]
   connattrAttr = [["name", "connectionAttribute"], ["value", ""], ["type", "java.lang.String"]]
   loginTOAttr = [["name", "loginTimeout"], ["value", 0], ["type", "java.lang.Integer"]]
   newsprops = []
   newsprops.append(dbnameAttr)
   newsprops.append(descAttr)
   newsprops.append(passwordAttr)
   newsprops.append(connattrAttr)
   newsprops.append(loginTOAttr) 
   psAttr = ["propertySet", [["resourceProperties", newsprops]]]
   attrs = [psAttr]
   AdminConfig.modify(ds, attrs)
   print AdminConfig.showall(ds)
    
   #--------------------------------------------------------------
   # Modify the DataSource to give it a relational resource adapter.
   # We use the built-in rra on the node. 
   #--------------------------------------------------------------
   print "ex9: modify the datasource object -- relationalResourceAdapter" 
   rra = AdminConfig.getid("/Node:" + nodeName + "/J2CResourceAdapter:WebSphere Relational Resource Adapter/")
   rraAttr = ["relationalResourceAdapter", rra]
   attrs = [rraAttr]
   AdminConfig.modify(ds, attrs)
    
   #---------------------------------------------------------
   # Create a CMPConnectorFactory, using the datasource from earlier 
   #---------------------------------------------------------
   print "ex9: create a new CMPConnectorFactory object named " + cfname
   nameAttr = ["name", cfname]
   authmechAttr = ["authMechanismPreference", "BASIC_PASSWORD"]
   cmpdsAttr = ["cmpDatasource", ds]
   propAttr = [["name", "TransactionResourceRegistration"], ["type", "java.lang.String"], ["value", "dynamic"], ["description", "Type of transaction resource registration (enlistment). Valid values are either static (immediate) or dynamic (deferred)."]] 
   newprops = []
   newprops.append(propAttr)
   psAttr = ["propertySet", [["resourceProperties", newprops]]]
   mapAuthAttr = ["authDataAlias", CONT_ALIAS] 
   mapConfigaliasAttr = ["mappingConfigAlias", DEFAULT_PRINCIPAL_MAPPING] 
   mapAttrs = []
   mapAttrs.append(mapAuthAttr)
   mapAttrs.append(mapConfigaliasAttr)
   mappingAttr = ["mapping", mapAttrs]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(authmechAttr)
   attrs.append(cmpdsAttr)
   attrs.append(psAttr)
   attrs.append(mappingAttr)
   newcf = AdminConfig.create("CMPConnectorFactory", rra, attrs)
 
   #--------------------------------------------------------------
   # Save all the changes 
   #--------------------------------------------------------------
   print "ex9: saving the configuration"
   AdminConfig.save()


#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv) != 7):
   print "ex9: this script requires 7 parameters: " 
   print "       1) the name of the node under which to create resources,"
   print "       2) the name of a JDBCProvider template to use,"
   print "       3) the fully-qualified path to the DB driver,"
   print "       4) the name of the JDBCProvider to create,"
   print "       5) the name of the datasource to create,"
   print "       6) the name of the CMPConnectionFactory to create,"
   print "       7) and the name of the database to use."
   print ""
   print "e.g.:     ex9 mynode \"DB2 JDBC Provider (XA)\" c:/SQLLIB/java/db2java.zip myds mycf sampleDB"
else:
   ex9(sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
