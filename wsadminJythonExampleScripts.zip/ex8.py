# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex8.py - Jython implementation of example script 8
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate J2C Security configuration,
#  including the installation of a J2CResourceAdapter and creation of a J2CConnectionFactory.
#
#  This script can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex8.py mynode c:/mystuff/cicseci.rar anonymous pw1 anonymous pw2
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex8.py") or execfile("ex8.py")
#     wsadmin> ex8("mynode", "c:/mystuff/cicseci.rar", "anonymous", "pw1", "anonymous", "pw2")
#
#  The script expects 6 parameters:
#    node name
#    path name for rar file to be used when installing J2CResourceAdapter
#    user id for component-managed authentication 
#    password for above
#    user id for container-managed authentication 
#    password for above
#
#  In addition, the script sets several constants that can be customized,
#  or this script could be adapted to take some or all of these as 
#  parameters:
#    the alias names for authentication 
#    the name of the new J2CConnectionFactory 
#    the jndiName of the new J2CConnectionFactory 
#    a string to be used when searching for an appropriate template
#    the path to the driver needed for this JDBCProvider
#
#  This example demonstrates these wsadmin features:
#
#   - The use of the AdminConfig object to locate configuration objects        
#   - The use of the AdminConfig object to create configuration objects
#   - The use of the AdminConfig object to modify configuration objects
#   - The use of the AdminConfig installResourceAdapter command to install J2CResourceAdapter objects 
#-----------------------------------------------------------------
#
import sys

def ex8(nodeName, rarpath, component_username, component_password, container_username, container_password): 
  
   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig
   global AdminControl

   COMP_ALIAS = "my-applicationAuth-Alias"
   CONT_ALIAS = "my-containerAuth-Alias"
   newCFname = "ECI_CF"
   newCFjndiName = "eis/becashacctECIConnection"
   DEFAULT_PRINCIPAL_MAPPING = "DefaultPrincipalMapping"

   #---------------------------------------------------------
   # Get the config id for the Cell's Security object 
   #---------------------------------------------------------
   print "ex8: get the cell's Security object" 
   cell = AdminControl.getCell()
   sec = AdminConfig.getid("/Cell:" + cell + "/Security:/")
 
   #---------------------------------------------------------
   # Install a J2CResourceAdapter using the provided rar file 
   #---------------------------------------------------------
   print "ex8: install resource adapter"
   ra = AdminConfig.installResourceAdapter(rarpath, nodeName, "[-rar.desc 'New Resource Adapter']")

   #---------------------------------------------------------
   # Create a JAASAuthData object for component-managed authentication 
   #---------------------------------------------------------
   print "ex8: create JAASAuthData object for component-managed authentication" 

   aliasAttr = ["alias", COMP_ALIAS]
   descAttr = ["description", "authentication information when component-managed"]
   useridAttr = ["userId", component_username]
   passwordAttr = ["password", component_password]
   attrs = []
   attrs.append(aliasAttr)
   attrs.append(descAttr)
   attrs.append(useridAttr)
   attrs.append(passwordAttr)
 
   appauthdata = AdminConfig.create("JAASAuthData", sec, attrs) 
 
   #---------------------------------------------------------
   # Create a JAASAuthData object for container-managed authentication 
   #---------------------------------------------------------
   print "ex8: create JAASAuthData object for container-managed authentication" 
 
   aliasAttr = ["alias", CONT_ALIAS]
   descAttr = ["description", "authentication information when container-managed"]
   useridAttr = ["userId", container_username]
   passwordAttr = ["password", container_password]
   attrs = []
   attrs.append(aliasAttr)
   attrs.append(descAttr)
   attrs.append(useridAttr)
   attrs.append(passwordAttr)
 
   contauthdata = AdminConfig.create("JAASAuthData", sec, attrs) 
 
   #---------------------------------------------------------
   # Create a J2CConnectionFactory 
   #---------------------------------------------------------
   print "ex8: create a J2CConnectionFactory named " + newCFname
   nameAttr = ["name", newCFname]
   jndiAttr = ["jndiName", newCFjndiName]
   authmechAttr = ["authMechanismPreference", "BASIC_PASSWORD"]
   authdataAttr = ["authDataAlias", COMP_ALIAS]
   mapAuthAttr = ["authDataAlias", CONT_ALIAS] 
   mapConfigaliasAttr = ["mappingConfigAlias", DEFAULT_PRINCIPAL_MAPPING] 
   mapAttrs = []
   mapAttrs.append(mapAuthAttr)
   mapAttrs.append(mapConfigaliasAttr)
   mappingAttr = ["mapping", mapAttrs]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(jndiAttr)
   attrs.append(authmechAttr)
   attrs.append(authdataAttr)
   attrs.append(mappingAttr)
 
   cf = AdminConfig.create("J2CConnectionFactory", ra, attrs)
 
   #--------------------------------------------------------------
   # Save all the changes 
   #--------------------------------------------------------------
   print "ex8: saving the configuration"
   AdminConfig.save()


#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv) != 6):
   print "ex8: this script requires 6 parameters: "
   print "     the name of the node under which to create resources,"
   print "     the path to the rar file, "
   print "     the user name to be used for component-managed authorization,"
   print "     the password to be used for component-managed authorization,"
   print "     the user name to be used for container-managed authorization,"
   print "     and the password to be used for container-managed authorization,"
   print ""
   print "e.g.:   ex8.jacl mynode c:/mystuff/cicseci.rar anonymous pw1 anonymous pw2"
else:
   ex8(sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
