# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex11.py - Jython implementation of example script 11
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the setting of various
#  port numbers kept in the serverindex.xml file.
#  
#  This script can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex11.py dmgrnode nodeManager 9809 8879 7989 5560 5561 7272 7273 7277
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex11.py") or execfile("ex11.py")
#     wsadmin> ex11("dmgnode", "nodeManager", "9809", "8879", "7989", "5560", "5561", "7272", "7273", "7277")
#
#  The script expects 9 parameters:
#    nodename 
#    node agent name
#    BOOTSTRAP_ADDRESS 
#    SOAP_CONNECTOR_ADDRESS 
#    DRS_CLIENT_ADDRESS 
#    JMSSERVER_QUEUED_ADDRESS
#    JMSSERVER_DIRECT_ADDRESS 
#    NODE_DISCOVERY_ADDRESS 
#    CELL_MULTICAST_DISCOVERY_ADDRESS 
#    CELL_DISCOVERY_ADDRESS
#
#  This example demonstrates these wsadmin features:
#
#   - The use of the AdminConfig object to locate configuration objects        
#   - The use of the AdminConfig object to modify configuration objects 
#-----------------------------------------------------------------
#
import sys

def ex11(nodeName, NAnodeName, bootstrap, soap, drs, jmsQueued, jmsDirect, nodediscovery, cellmultdiscovery, celldiscovery):
  
   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig

   #---------------------------------------------------------
   # Get the config id for the node
   #---------------------------------------------------------
   print "ex11: getting the config id for the node"
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   if len(node) == 0:
      print "ex11: could not find the node name: " + nodeName
      return
      
   #---------------------------------------------------------
   # Get the config id for the deployment manager 
   #---------------------------------------------------------
   print "ex11: getting the config id for the deployment manager" 
   dmgr = AdminConfig.getid("/Node:" + nodeName + "/Server:dmgr/")
   if len(dmgr) == 0:
      print "ex11: could not find the deployment manager server"
      return

   #---------------------------------------------------------
   # Get the config id for the node agent 
   #---------------------------------------------------------
   print "ex11: getting the config id for the node agent" 
   naServer = AdminConfig.getid("/Node:" + NAnodeName + "/Server:nodeagent/")
   if len(naServer) == 0:
      print "ex11: could not find the node agent server"
 
   #---------------------------------------------------------
   # Set the BOOTSTRAP_ADDRESS port 
   #
   # This is an attribute on the NameServer object inside the Server.  
   # To modify this endpoint, you need to get the id of the NameServer
   # and invoke modify:
   #---------------------------------------------------------
   print "ex11: setting the BOOTSTRAP_ADDRESS port to " + bootstrap
   ns = AdminConfig.list("NameServer", dmgr)
   portAttr = ["port", bootstrap]
   hostAttr = ["host", nodeName]
   bootAttrs = ["BOOTSTRAP_ADDRESS", [portAttr, hostAttr]]
   attrs = [bootAttrs]
   AdminConfig.modify(ns, attrs)

   #---------------------------------------------------------
   # set the SOAP_CONNECTOR_ADDRESS port
   #
   # This is an attribute on the SOAPConnector object inside the Server.  
   # To modify this endpoint, you need to get the id of the SOAPConnector 
   # and invoke modify:
   #---------------------------------------------------------
   print "ex11: setting the SOAP_CONNECTOR_ADDRESS port to " + soap
   soapC = AdminConfig.list("SOAPConnector", dmgr)
   portAttr = ["port", soap]
   hostAttr = ["host", nodeName]
   soapAttrs = ["SOAP_CONNECTOR_ADDRESS", [portAttr, hostAttr]]
   attrs = [soapAttrs]
   AdminConfig.modify(soapC, attrs)

   #---------------------------------------------------------
   # set the DRS_CLIENT_ADDRESS port
   #
   # This is an attribute on the SystemMessageServer object inside the Server.  
   # To modify this endpoint, you need to get the id of the SystemMessageServer 
   # and invoke modify:
   #---------------------------------------------------------
   print "ex11: setting the DRS_CLIENT_ADDRESS port to " + drs
   sms = AdminConfig.list("SystemMessageServer", dmgr)
   if len(sms) == 0:
      print "ex11: skipping DRS_CLIENT_ADDRESS because SystemMessageServer not found" 
   else:
      portAttr = ["port", drs]
      hostAttr = ["host", nodeName]
      drsAttrs = ["DRS_CLIENT_ADDRESS", [portAttr, hostAttr]]
      attrs = [drsAttrs]
      AdminConfig.modify(sms, attrs)

   #---------------------------------------------------------
   # set the JMSSERVER_QUEUED_ADDRESS and JMSSERVER_DIRECT_ADDRESS ports
   #
   # These are attributes on the JMSServer object inside the Server.  
   # To modify these endpoints, you need to get the id of the JMSServer 
   # and invoke modify:
   #---------------------------------------------------------
   print "ex11: setting the JMSSERVER_QUEUED_ADDRESS port to " + jmsQueued + " and the JMSSERVER_DIRECT_ADDRESS port to " + jmsDirect 
   jms = AdminConfig.list("JMSServer", dmgr)
   if len(jms) == 0:
      print "ex11: skipping JMS addresses because JMSServer not found" 
   else:
      portAttr = ["port", jmsQueued]
      hostAttr = ["host", nodeName]
      jmsqAttrs = ["JMSSERVER_QUEUED_ADDRESS", [portAttr, hostAttr]]
      attrs = [jmsqAttrs]
      AdminConfig.modify(jms, attrs) 
 
      portAttr = ["port", jmsDirect]
      hostAttr = ["host", nodeName]
      jmsdAttrs = ["JMSSERVER_DIRECT_ADDRESS", [portAttr, hostAttr]]
      attrs = [jmsdAttrs]
      AdminConfig.modify(jms, attrs) 
 
   #---------------------------------------------------------
   # set the NODE_DISCOVERY_ADDRESS port
   #
   # This is an attribute on the NodeAgent object inside the node agent Server.  
   # To modify this endpoint, you need to get the id of the NodeAgent 
   # and invoke modify:
   #---------------------------------------------------------
   if len(naServer) == 0:
      print "ex11: skipping NODE_DISCOVERY_ADDRESS because node agent not found." 
   else:
      print "ex11: setting the NODE_DISCOVERY_ADDRESS port to " + nodediscovery 
      na = AdminConfig.list("NodeAgent", naServer)
      portAttr = ["port", nodediscovery]
      hostAttr = ["host", NAnodeName]
      ndAttrs = ["NODE_DISCOVERY_ADDRESS", [portAttr, hostAttr]]
      attrs = [ndAttrs]
      AdminConfig.modify(na, attrs) 
 
   #---------------------------------------------------------
   # set the CELL_MULTICAST_DISCOVERY_ADDRESS and CELL_DISCOVERY_ADDRESS ports
   #
   # These are attributes on the CellManager object inside the Server.  
   # To modify these endpoints, you need to get the id of the CellManager 
   # and invoke modify:
   #---------------------------------------------------------
   print "ex11: setting the CELL_MULTICAST_DISCOVERY_ADDRESS port to " + cellmultdiscovery + " and the CELL_DISCOVERY_ADDRESS port to " + celldiscovery
   cm = AdminConfig.list("CellManager", dmgr)
   portAttr = ["port", cellmultdiscovery]
   hostAttr = ["host", nodeName]
   cmdaAttrs = ["CELL_MULTICAST_DISCOVERY_ADDRESS", [portAttr, hostAttr]]
   attrs = [cmdaAttrs]
   AdminConfig.modify(cm, attrs)
 
   portAttr = ["port", celldiscovery]
   hostAttr = ["host", nodeName]
   cdaAttrs = ["CELL_DISCOVERY_ADDRESS", [portAttr, hostAttr]]
   attrs = [cdaAttrs]
   AdminConfig.modify(cm, attrs)
 
 
   #---------------------------------------------------------
   # save the changes 
   #---------------------------------------------------------
   print "ex11: saving the configuration"
   AdminConfig.save()
 

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv) != 10):
   print "ex11: this script requires 10 parameters: " 
   print "       1) the name of the Deployment Manager node"
   print "       2) the name of the Node Agent node"
   print "       3) the value of BOOTSTRAP_ADDRESS "
   print "       4) the value of SOAP_CONNECTOR_ADDRESS "
   print "       5) the value of DRS_CLIENT_ADDRESS "
   print "       6) the value of JMSSERVER_QUEUED_ADDRESS"
   print "       7) the value of JMSSERVER_DIRECT_ADDRESS "
   print "       8) the value of NODE_DISCOVERY_ADDRESS "
   print "       9) the value of CELL_MULTICAST_DISCOVERY_ADDRESS "
   print "      10) the value of CELL_DISCOVERY_ADDRESS"
   print ""
   print "e.g.:     ex11 dmgrnode othernode 9809 8879 7989 5560 5561 7272 7273 7277"
else:
   ex11(sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7], sys.argv[8], sys.argv[9])
