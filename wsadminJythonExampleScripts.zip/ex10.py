# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex10.py - Jython implementation of example script 10
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the creation and 
#  use of a variable.  The variable created is used in the creation
#  of a URLProvider object. 
#  
#  This script can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex10.py mynode 
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex10.py") or execfile("ex10.py")
#     wsadmin> ex10("mynode")
#
#  The script expects 1 parameter:
#    node name
#
#  This example demonstrates these wsadmin features:
#
#   - The use of the AdminConfig object to locate configuration objects        
#   - The use of the AdminConfig object to create configuration objects 
#-----------------------------------------------------------------
#
import sys

def ex10(nodeName):
  
   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig
   urlName = "Quote"
   jarName = "QuoteURLProvider.jar"
   streamHandlerClassName = "com.ibm.ejs.sm.fvt.url.QuoteURLStreamHandler"
   protocolName = "quote" 

   #---------------------------------------------------------
   # Get the config id for the node
   #---------------------------------------------------------
   print "ex10: getting the config id for the node"
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   if len(node) == 0:
      print "ex10: could not find a Node object called " + nodeName
      return

   #---------------------------------------------------------
   # Get the config id for the node's variable map
   #---------------------------------------------------------
   print "ex10: getting the config id for the variable map object on node " + nodeName
   varmap = AdminConfig.getid("/Node:" + nodeName + "/VariableMap:/")
   if len(varmap) == 0:
      print "ex10: could not find a VariableMap object in node " + nodeName
      return
 
   #---------------------------------------------------------
   # Create a mapping 
   #---------------------------------------------------------
   print "ex10: create a variable in the variable map" 
   nameAttr = ["symbolicName", "WAS_CLASSES_DIR"] 
   valAttr = ["value", "\${WAS_INSTALL_ROOT}/classes"] 
   attrs = []
   attrs.append(nameAttr)
   attrs.append(valAttr)
   AdminConfig.create("VariableSubstitutionEntry", varmap, attrs)
 
   #---------------------------------------------------------
   # Create a new URLProvider using this variable in the classpath attribute 
   #---------------------------------------------------------
   print "ex10: create a new URLProvider object using this variable" 
   nameAttr = ["name", urlName]
   cpAttr = ["classpath", "\${WAS_CLASSES_DIR}/" + jarName]
   shAttr = ["streamHandlerClassName", streamHandlerClassName]
   protAttr = ["protocol", protocolName]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(cpAttr)
   attrs.append(shAttr)
   attrs.append(protAttr)
   urlp = AdminConfig.create("URLProvider", node, attrs)
 
   #---------------------------------------------------------
   # Create new URLs using this URLProvider 
   #---------------------------------------------------------
   print "ex10: create new URL objects using this URLProvider" 
   nameAttr = ["name", "MyCompany"]
   jndiNameAttr = ["jndiName", "url/MyCompany"]
   specAttr = ["spec", "quote://MyCompany"]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(jndiNameAttr)
   attrs.append(specAttr)
   AdminConfig.create("URL", urlp, attrs)
 
   nameAttr = ["name", "YourCompany"]
   jndiNameAttr = ["jndiName", "url/YourCompany"]
   specAttr = ["spec", "quote://YourCompany"]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(jndiNameAttr)
   attrs.append(specAttr)
   AdminConfig.create("URL", urlp, attrs)
 
 
   #--------------------------------------------------------------
   # Save all the changes 
   #--------------------------------------------------------------
   print "ex10: saving the configuration"
   AdminConfig.save()


#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv) != 1):
   print "ex10: this script requires 1 parameters: " 
   print "       1) the name of the node under which to create resources"
   print ""
   print "e.g.:     ex10 mynode" 
else:
   ex10(sys.argv[0])
