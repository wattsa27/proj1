# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex4.py - Jython implementation of example script 4
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the invocation  
#  of some useful problem-determination actions involving traces 
#  and thread dumps.
#  
#  This script it can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex4.py server1 mynode
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex4.py") or execfile("ex4.py")
#     wsadmin> ex4("server1", "mynode")
#
#  The script expects one parameter:
#      arg1 - server name
#      arg2 - node name
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminControl object to locate running MBeans 
#   - The use of the AdminControl object to getAttributes from running MBeans 
#   - The use of the AdminControl object to invoke operations on running MBeans 
#   - The use of the Help object to display MBean information
#-----------------------------------------------------------------
#
import sys

def ex4(serverName, nodeName):

   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminControl
   global Help


   #---------------------------------------------------------
   # Get the TraceService MBean for this server 
   #---------------------------------------------------------
   traceServ = AdminControl.completeObjectName("type=TraceService,node=" + nodeName + ",process=" + serverName + ",*")
   print "server name " + serverName

   #---------------------------------------------------------
   # Display the help information for this MBean 
   # 
   #---------------------------------------------------------
   if traceServ != "":
      print Help.all(traceServ)
   else:
      print "TraceService is not available on server " + serverName + " node " + nodeName
      return 
   
   #---------------------------------------------------------
   # Get the current value of traceSpecification 
   # 
   #---------------------------------------------------------
   specOrig = AdminControl.getAttribute(traceServ, "traceSpecification")
   print "Current trace specification is " + specOrig

   #---------------------------------------------------------
   # Set it to something else 
   # 
   #---------------------------------------------------------
   AdminControl.setAttribute(traceServ, "traceSpecification", "com.ibm.ws.management.*=all=enabled")

   #---------------------------------------------------------
   # Append to it              
   # 
   #---------------------------------------------------------
   AdminControl.invoke(traceServ, "appendTraceString", "com.ibm.websphere.management.*=all=enabled")

   #---------------------------------------------------------
   # Now get the current value of traceSpecification again 
   # 
   #---------------------------------------------------------
   spec = AdminControl.getAttribute(traceServ, "traceSpecification")
   print "Current trace specification is now " + spec

   #---------------------------------------------------------
   # Set it back 
   # 
   #---------------------------------------------------------
   AdminControl.setAttribute(traceServ, "traceSpecification", specOrig)
   spec = AdminControl.getAttribute(traceServ, "traceSpecification")
   print "Current trace specification is set back to " + spec

   #---------------------------------------------------------
   # Get the JVM MBean for this server 
   #---------------------------------------------------------
   jvm = AdminControl.completeObjectName("type=JVM,node=" + nodeName + ",process=" + serverName + ",*")

   #---------------------------------------------------------
   # Display the help information for this MBean 
   # 
   #---------------------------------------------------------
   print Help.all(jvm)
   print Help.operations(jvm, "getProperty")

   #---------------------------------------------------------
   # invoke an action: getProperty 
   # 
   #---------------------------------------------------------
   jversion = AdminControl.invoke(jvm, "getProperty", "java.fullversion")
   print "java.fullversion is " + jversion

   #---------------------------------------------------------
   # invoke an action: dumpThreads 
   # 
   #---------------------------------------------------------
   print "About to dump threads for this jvm..."
   AdminControl.invoke(jvm, "dumpThreads")
   print "... done"


#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if len(sys.argv) != 2:
   print "ex4: this script requires 2 parameter: server name, node name"
   print ""
   print "e.g.:     ex4  server1 mynode" 
else:
   ex4(sys.argv[0], sys.argv[1])
