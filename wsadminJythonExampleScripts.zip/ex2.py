# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex2.py - Jython implementation of example script 2 
#-----------------------------------------------------------------
#
#  The purpose of this example is to show a potentially useful
#  sequence of common actions using the scripting client wsadmin.
#  This example is the reverse of example ex1, albeit somewhat simpler.
#  It stops a server on a given node, uninstalls the given application,
#  and removes the server from the configuration.
#
#  We assume an environment
#  in which the scripting client is attached to the Network Deployment
#  manager, but much of this script could be used in a base install.
#  
#  This script it can be included in the wsadmin command invocation like this:
#     wsadmin -lang jython -f ex2.py serverX nodeY myapp
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex2.py") or execfile("ex2.py")
#     wsadmin> ex2("serverX", "nodeY", "myapp")
#
#  The script expects some parameters:
#      arg1 - server name
#      arg2 - node name
#      arg3 - application name
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminApp object to uninstall an application
#   - The use of the AdminControl object to locate running MBeans 
#   - The use of the AdminControl object's "stopServer" command
#   - The use of the AdminConfig object to remove objects from the configuration
#   - The use of the AdminConfig object to find objects in the configuration
#   - The use of the AdminConfig object to save the configuration
#-----------------------------------------------------------------
import sys

def ex2(serverName, nodeName, appName):

   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig
   global AdminControl
   global AdminApp

   #--------------------------------------------------------------
   # do some sanity checking 
   #     -- do we have a node by this name? 
   #--------------------------------------------------------------
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   print "ex1: checking for existence of node " + nodeName
   if len(node) == 0:
      print "ex2: Error -- node not found for name " + nodeName
      return

   #--------------------------------------------------------------
   #     -- is a server by this name already running on the node? 
   #--------------------------------------------------------------
   print "ex2: checking to see if server " + serverName + " is running on node " + nodeName
   runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
   if len(runningServer) == 0:
      print "ex2: Error -- Server " + serverName + " not running on node " + nodeName
      return 

   #--------------------------------------------------------------
   # stop the server 
   #--------------------------------------------------------------
   print "ex2: stopping server $serverName ..."
   AdminControl.stopServer(serverName, nodeName)
   print "ex2: done."

   #--------------------------------------------------------------
   # Uninstall the application 
   #--------------------------------------------------------------
   print "ex2: uninstalling the application"
   AdminApp.uninstall(appName)

   #--------------------------------------------------------------
   # Find the configuration object 
   #--------------------------------------------------------------
   server = AdminConfig.getid("/Node:" + nodeName + "/Server:" + serverName + "/");

   #--------------------------------------------------------------
   # Remove it 
   #--------------------------------------------------------------
   AdminConfig.remove(server)

   #--------------------------------------------------------------
   # Save all the changes 
   #--------------------------------------------------------------
   print "ex2: saving the configuration"
   AdminConfig.save()

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if len(sys.argv) != 3:
   print "ex2: this script requires 3 parameters: server name, node name, and application name"
   print "e.g.:     ex2  server2 mynode myapp1" 
else:
   ex2(sys.argv[0], sys.argv[1], sys.argv[2])
