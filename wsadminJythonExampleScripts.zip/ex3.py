# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex3.py - Jython implementation of example script 3
#-----------------------------------------------------------------
#
#  The purpose of this example is to show a potentially useful
#  sequence of common actions using the scripting client wsadmin.
#  This example creates a cluster 
#  onto the server, and starts the server.  We assume an environment
#  in which the scripting client is attached to the Network Deployment
#  manager.
#  
#  This script can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex3.py cl1 "node1 node2 node3" clserv 1 10 c:/applicationZ myapp
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex3.py") or execfile("ex3.py")
#     wsadmin> ex3("cl1", "(node1 node2 node3)", "clserv", 1, 10, "c:/applicationZ", "myapp")
#
#  The script expects some parameters:
#      arg1 - cluster name
#      arg2 - list of node names
#      arg3 - prefix to be used on server names
#      arg4 - number of servers to be created per node
#      arg5 - weight of each server in the group 
#      arg6 - application ear file to be loaded 
#      arg7 - application name (optional) 
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminApp object to install an application
#   - The use of the AdminControl object to locate running MBeans 
#   - The use of the AdminControl object to getAttributes from running MBeans 
#   - The use of the AdminControl object to invoke operations on running MBeans 
#   - The use of the AdminControl object's "startServer" command
#   - The use of the AdminConfig object to create objects in the configuration
#   - The use of the AdminConfig object to find objects in the configuration
#   - The use of the AdminConfig object to modify objects in the configuration
#   - The use of the AdminConfig object to save the configuration
#   - Methods for saving and synchronizing the configuration.
#-----------------------------------------------------------------
#
import sys
from time import sleep

def ex3(clusterName, nodes, namePrefix, serversPerNode, weight, app, appName=None):

   #--------------------------------------------------------------
   # check for optional argument 
   #--------------------------------------------------------------
   if (appName is None):
      appName = ""

   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig
   global AdminControl
   global AdminApp

   #---------------------------------------------------------
   # We assume that there is only one cell, and we are on it
   #---------------------------------------------------------
   cellName = AdminControl.getCell()
   cell = AdminConfig.getid("/Cell:" + cellName + "/")
 
   #---------------------------------------------------------
   # Construct the attribute list to be used in creating a ServerCluster 
   # attribute.      
   #---------------------------------------------------------
   nameAttr = ["name", clusterName]
   descAttr = ["description", "test cluster"]
   prefAttr = ["preferLocal", "true"]
   stateAttr = ["stateManagement", [["initialState", "STOP"]]]
   attrs = []
   attrs.append(nameAttr)
   attrs.append(descAttr)
   attrs.append(prefAttr)
   attrs.append(stateAttr)
  
   #---------------------------------------------------------
   # Create the server cluster 
   #---------------------------------------------------------
   print "ex3: creating the ServerCluster " + clusterName
   cluster = AdminConfig.create("ServerCluster", cell, attrs)

   #--------------------------------------------------------------
   # Install an application onto this server
   #--------------------------------------------------------------
   print "ex3: installing the application"
   appOptions = "[-cluster " + clusterName 
   if len(appName) > 0:
      appOptions = appOptions + " -appname " + appName
   appOptions = appOptions + "]"
   AdminApp.install(app, appOptions)

   #---------------------------------------------------------
   # For each node, create the required number of servers
   # 
   #---------------------------------------------------------
   nodeList = nodes.split(" ")
   index = 1
   for nodeName in nodeList:
      node = AdminConfig.getid("/Node:" + nodeName + "/")
      loop = 0
      while ("%s" % (loop)) != serversPerNode:
         print "loop: %s; serversPerNode: %s" % (loop, serversPerNode)
         uid = "%s_%s" % (index, loop)
         servName = namePrefix + "_" + uid
         nameAttr = ["memberName", servName]
         weightAttr = ["weight", weight]
         attrs = []
         attrs.append(nameAttr)
         attrs.append(weightAttr)
         print "ex3: creating server " + servName + " on node " + nodeName
         server = AdminConfig.createClusterMember(cluster, node, attrs)
         loop = loop + 1
      index = index + 1
 
   #---------------------------------------------------------
   # save changes 
   # 
   #---------------------------------------------------------
   print "ex3: saving config changes."
   AdminConfig.save()

   #---------------------------------------------------------
   # Ask the ClusterMgr to refresh its list of clusters 
   # 
   #---------------------------------------------------------
   clusterMgr = AdminControl.completeObjectName("type=ClusterMgr,cell=" + cellName + ",*")
   if len(clusterMgr) == 0:
      print "ex3: Error -- clusterMgr MBean not found for cell " + cellName
      return 
   AdminControl.invoke(clusterMgr, "retrieveClusters")

   #---------------------------------------------------------
   # For each node, invoke a sync if necessary 
   #     -- Is a nodeSync MBean available on this node? 
   #     -- Find out if serverStartupSyncEnabled is true for this node
   #        We just created this server, so if this attribute is set to
   #        "false" we have to perform a sync.  If we do not, the node we
   #        are installing on may have an out-of-date copy of the config
   #        data. 
   #---------------------------------------------------------
   for nodeName in nodeList:
      node = AdminConfig.getid("/Node:" + nodeName + "/")
      print "ex3: checking for the existence of a NodeSync MBean on node " + nodeName
      nodeSync = AdminControl.completeObjectName("type=NodeSync,node=" + nodeName + ",*")
      if len(nodeSync) == 0:
         print "ex3: Error -- NodeSync MBean not found for name " + nodeName
         return 
      enabled = AdminControl.getAttribute(nodeSync, "serverStartupSyncEnabled")
      if enabled == "false":
         print "ex3: Invoking synchronization for node " + nodeSync + " because serverStartupSyncEnabled is set to false..."
         AdminControl.invoke(nodeSync, "sync")
         sleep(20)
         print "ex3: Done with synchronization."
  
   #---------------------------------------------------------
   # Ask the Cluster MBean to start the cluster
   # 
   #---------------------------------------------------------
   cluster = AdminControl.completeObjectName("type=Cluster,name=" + clusterName + ",*")
   print "ex3: Invoking start for cluster " + clusterName
   AdminControl.invoke(cluster, "start")


#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if (len(sys.argv) != 6) and (len(sys.argv) != 7):
   print "ex3: this script requires 6 or 7 parameters: cluster name, "
   print "     list of node names, server name prefix, number of servers"
   print "     per node, weight of each server, ear file, and (optionally)"
   print "     application name"
   print ""
   print "e.g.:     ex3  cl1 \"mynode1 mynode2\" serv 1 10 c:/WebSphere/AppServer/installableApps/jmsample.ear myapp1" 
else:
   if len(sys.argv) == 6:
      ex3(sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
   else:
      ex3(sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
