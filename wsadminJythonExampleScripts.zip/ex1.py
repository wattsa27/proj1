# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex1.py - Jython implementation of example script 1 
#-----------------------------------------------------------------
#
#  The purpose of this example is to show a potentially useful
#  sequence of common actions using the scripting client wsadmin.
#  This example creates and modifies a server, loads an application
#  onto the server, and starts the server.  We assume an environment
#  in which the scripting client is attached to the Network Deployment
#  manager, but much of this script could be used in a base install.
#  
#  This script can be included in the wsadmin command invocation like this:
#     wsadmin -lang jython -f ex1.py serverX nodeY c:/applicationZ myapp
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex1.py") or execfile("ex1.py")
#     wsadmin> ex1("serverX", "nodeY", "c:/applicationZ", "myapp")
#
#  The script expects some parameters:
#      arg1 - server name
#      arg2 - node name
#      arg3 - application 
#      arg4 - application name (optional) 
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminApp object to install an application
#   - The use of the AdminControl object to locate running MBeans 
#   - The use of the AdminControl object to getAttributes from running MBeans 
#   - The use of the AdminControl object to invoke operations on running MBeans 
#   - The use of the AdminControl object's "startServer" command
#   - The use of the AdminConfig object to create objects in the configuration
#   - The use of the AdminConfig object to find objects in the configuration
#   - The use of the AdminConfig object to modify objects in the configuration
#   - The use of the AdminConfig object to save the configuration
#   - Methods for saving and synchronizing the configuration.
#-----------------------------------------------------------------
import sys
from time import sleep

def ex1(serverName, nodeName, app, appName=None):

   #--------------------------------------------------------------
   # check for optional argument 
   #--------------------------------------------------------------
   if (appName is None):
      appName = ""

   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminConfig
   global AdminControl
   global AdminApp

   #--------------------------------------------------------------
   # do some sanity checking 
   #     -- do we have a node by this name? 
   #--------------------------------------------------------------
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   print "ex1: checking for existence of node " + nodeName
   if len(node) == 0:
      print "ex1: Error -- node not found for name " + nodeName
      return


   #--------------------------------------------------------------
   #     -- is a server by this name already running on the node? 
   #--------------------------------------------------------------
   print "ex1: checking to see if server " + serverName + " is already running on node " + nodeName
   runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
   if len(runningServer) > 0:
      print "ex1: Error -- Server " + serverName + " already running on node " + nodeName
      return 
 


   #--------------------------------------------------------------
   #     -- is a nodeSync MBean available on this node? 
   #--------------------------------------------------------------
   print "ex1: checking for the existence of a NodeSync MBean on node " + nodeName
   nodeSync = AdminControl.completeObjectName("type=NodeSync,node=" + nodeName + ",*")
   if len(nodeSync) == 0:
      print "ex1: Error -- NodeSync MBean not found for name " + nodeName
      return 
      

   #--------------------------------------------------------------
   # Create a server using the supplied server name and node 
   #--------------------------------------------------------------
   print "ex1: creating a server " + serverName + "....."
   attributes = [["name", serverName]]
   server = AdminConfig.create("Server", node, attributes)

 
   #--------------------------------------------------------------
   # Change the list of transports associated with the WebContainer
   # for this server.  Create one secure and one non-secure transport 
   #--------------------------------------------------------------
   print "ex1: modifying HTTP port addresses"
   httpNonSecureAddress = [["sslEnabled", "false"], ["address", [["host", ""], ["port", 9088]]]]
   httpSecureAddress = [["sslEnabled", "true"], ["address", [["host", ""], ["port", 9948]]], ["sslConfig", "DefaultSSLSettings"]]
   transports = [["transports:HTTPTransport", [httpNonSecureAddress, httpSecureAddress]]]
   webContainer = AdminConfig.list("WebContainer", server)
   AdminConfig.modify(webContainer, transports)


   #--------------------------------------------------------------
   # Install an application onto this server
   #--------------------------------------------------------------
   print "ex1: installing the application"
   appOptions = "[-server " + serverName + " -node " + nodeName
   if len(appName) != 0:
      appOptions = appOptions + " -appname " + appName
   appOptions = appOptions + "]"
   AdminApp.install(app, appOptions)

   #--------------------------------------------------------------
   # Save all the changes 
   #--------------------------------------------------------------
   print "ex1: saving the configuration"
   AdminConfig.save()

   #--------------------------------------------------------------
   # Find out if serverStartupSyncEnabled is true for this node
   # We just created this server, so if this attribute is set to
   # "false" we have to perform a sync.  If we do not, the node we
   # are installing on may have an out-of-date copy of the config
   # data. 
   #--------------------------------------------------------------
   enabled = AdminControl.getAttribute(nodeSync, "serverStartupSyncEnabled")
   if enabled == "false":
      print "ex1: Invoking synchronization for node " + nodeSync + " because serverStartupSyncEnabled is set to false..."
      AdminControl.invoke(nodeSync, "sync")
      sleep(20)
      print "ex1: Done with synchronization."


   #--------------------------------------------------------------
   # start the server 
   #--------------------------------------------------------------
   print "ex1: starting server " + serverName + "..."
   AdminControl.startServer(serverName, nodeName)
   print "ex1: done."

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------

if (len(sys.argv) != 3) and (len(sys.argv) != 4):
   print "ex1: this script requires 3 or 4 parameters: server name, node name, ear file, and (optionally) application name"
   print "e.g.:     ex1  server2 mynode c:/WebSphere/AppServer/installableApps/jmsample.ear myapp1" 
else:   
   serverName = sys.argv[0]
   nodeName = sys.argv[1]
   application = sys.argv[2]
   appName = ""
   if len(sys.argv) == 4:
      appName = sys.argv[3]
   print "server: " + serverName
   print "node: " + nodeName
   print "application: " + application
   print "app name: " + appName
   ex1(serverName, nodeName, application, appName)
