# This program may be used, executed, copied, modified and distributed
# without royalty for the purpose of developing, using, marketing, or distribution

#-----------------------------------------------------------------
# ex5.py - Jython implementation of example script 5
#-----------------------------------------------------------------
#
#  The purpose of this example is to demonstrate the invocation  
#  of various application install commands.
#  
#  This script can be included in the wsadmin command invocation like this:
#     
#     wsadmin -lang jython -f ex5.py c:/WebSphere/AppServer/installableApps mynode server1
#
#  or the script can be execfiled from the wsadmin command line like this:
#     wsadmin> execfile ("ex5.py") or execfile("ex5.py")
#     wsadmin> ex5("c:/WebSphere/AppServer/installableApps", "mynode", "server1")
#
#  The script expects one parameter:
#      arg1 - location of DefaultApplication.ear
#      arg2 - nodeName
#      arg3 - serverName
#
#  This example demonstrates many wsadmin features:
#
#   - The use of the AdminApp object to install and uninstall applications 
#-----------------------------------------------------------------
#
import sys

def ex5(location, nodeName, serverName):

   #--------------------------------------------------------------
   # set up globals
   #--------------------------------------------------------------
   global AdminApp
   global AdminControl
   global AdminConfig
   global Help

   #--------------------------------------------------------------
   # do some sanity checking 
   #     -- do we have a node by this name? 
   #--------------------------------------------------------------
   cellName = AdminControl.getCell()
   node = AdminConfig.getid("/Node:" + nodeName + "/")
   print "ex5: checking for existence of node " + nodeName
   if len(node) == 0:
      print "ex5: Error -- node not found for name " + nodeName
      return 

   #---------------------------------------------------------
   # First, list the existing applications 
   #---------------------------------------------------------
   apps = AdminApp.list()
   print "Installed applications: "
   print apps

   #---------------------------------------------------------
   # Here is the ear file we'll be dealing with... 
   #---------------------------------------------------------
   defapp = location + "/DefaultApplication.ear"

   #---------------------------------------------------------
   # A very simple install command 
   #---------------------------------------------------------
   print "----------------------------------------------------------"
   print "A simple install command first..."
   appOptions = ["-appname", "app1", "-node", nodeName, "-server", serverName]
   AdminApp.install(defapp, appOptions)

   #---------------------------------------------------------
   # Demonstrate the default bindings capabilities
   # This example could include -usedefaultbindings by itself, but
   # we provide some additional options 
   #---------------------------------------------------------
   print "----------------------------------------------------------"
   print "Use the defaultbindings options..."
   appOptions = ["-appname", "app2", "-node", nodeName, "-server", serverName]

   bindingOptions = ["-usedefaultbindings", "-defaultbinding.datasource.jndi", "ds1", "-defaultbinding.datasource.username", "user1", "-defaultbinding.datasource.password", "pw1", "-defaultbinding.cf.jndi", "ds1", "-defaultbinding.ejbjndi.prefix", "ds2", "-defaultbinding.virtual.host", "myvh"]
   appOptions.extend(bindingOptions)

   AdminApp.install(defapp, appOptions)

   #---------------------------------------------------------
   # Demonstrate installation on a different server.  We will specify
   # server2, but override that setting for one module so that it will
   # be deployed on server1.
   # 
   #---------------------------------------------------------
   print "----------------------------------------------------------"
   print "Use a different server..."
   AdminConfig.create("Server", node, "[['name' 'server2']]")
   appOptions = ["-appname", "app3", "-server", "server2", "-node", nodeName]

   serv = "WebSphere:cell=" + cellName + ",node=" + nodeName + ",server=" + serverName
   mapping = [["Increment Enterprise Java Bean", "Increment.jar,META-INF/ejb-jar.xml", serv]] 
   moduleToServerTaskOption = ["-MapModulesToServers", mapping]
   appOptions.extend(moduleToServerTaskOption)

   AdminApp.install(defapp, appOptions)

   #---------------------------------------------------------
   # Demonstrate installation with a number of different settings.
   # Although this can get complex, note that you can always perform
   # an interactive install, then examine the wsadmin.traceout file, looking
   # for WASX7278I -- this message should include install options generated
   # from the interactive install that can be cut and pasted into scripts. 
   # 
   #---------------------------------------------------------
   print "----------------------------------------------------------"
   print "Specify several options."

   nameOpt = ["-appname", "app4"]
   nodeOpt = ["-node", nodeName]

   mapJndiBindOptValue = [["Increment Enterprise Java Bean", "Increment", "Increment.jar,META-INF/ejb-jar.xml", "Increment"]]
   mapJndiBindOpt = ["-BindJndiForEJBNonMessageBinding", mapJndiBindOptValue]

   mapEjbRefOptValue = [["Default Web Application", "", "DefaultWebApplication.war,WEB-INF/web.xml", "Increment", "com.ibm.defaultapplication.Increment", "Increment"]]
   mapEjbRefOpt = ["-MapEJBRefToEJB", mapEjbRefOptValue]

   mapDsEjbOptValue = [["Increment Enterprise Java Bean", "Increment.jar,META-INF/ejb-jar.xml", "DefaultDatasource", "cmpBinding.perConnectionFactory"]]
   mapDsEjbOpt = ["-DataSourceFor20EJBModules", mapDsEjbOptValue] 

   mapDsCmpOptValue = [["Increment Enterprise Java Bean", "Increment", "Increment.jar,META-INF/ejb-jar.xml", "DefaultDatasource", "cmpBinding.perConnectionFactory"]]
   mapDsCmpOpt = ["-DataSourceFor20CMPBeans", mapDsCmpOptValue] 

   mapVhOptValue = [["Default Web Application", "DefaultWebApplication.war,WEB-INF/web.xml", "default_host"]]
   mapVhOpt = ["-MapWebModToVH", mapVhOptValue] 

   serv = "WebSphere:cell=" + cellName + ",node=" + nodeName + ",server=" + serverName
   mapServerOptValue = [["Increment Enterprise Java Bean", "Increment.jar,META-INF/ejb-jar.xml", serv], ["Default Web Application", "DefaultWebApplication.war,WEB-INF/web.xml", serv]] 
   mapServerOpt = ["-MapModulesToServers", mapServerOptValue]
   
   miscOpts = ["-nopreCompileJSPs", "-distributeApp", "-nouseMetaDataFromBinary", "-nodeployejb"]

   appOptions = []
   appOptions.extend(nameOpt)
   appOptions.extend(nodeOpt)
   appOptions.extend(mapJndiBindOpt)
   appOptions.extend(mapEjbRefOpt)
   appOptions.extend(mapDsEjbOpt)
   appOptions.extend(mapDsCmpOpt)
   appOptions.extend(mapVhOpt)
   appOptions.extend(mapServerOpt)
   appOptions.extend(miscOpts)

   AdminApp.install(defapp, appOptions)

   #---------------------------------------------------------
   # Demonstrate ejb deploy options.
   # 
   #---------------------------------------------------------
   print "----------------------------------------------------------"
   print "Specify ejb deploy options."
  
   nameOpt = ["-appname", "app5"]
   nodeOpt = ["-node", nodeName]
   deployOpt = ["-deployejb", "-deployejb.dbtype", "DB2UDB_V72"]

   appOptions = []
   appOptions.extend(nameOpt)
   appOptions.extend(deployOpt)
 
   AdminApp.install(defapp, appOptions)
   
   #---------------------------------------------------------
   # Save all the changes
   #---------------------------------------------------------
   print "ex5: saving the configuration"
   AdminConfig.save()
 

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
if len(sys.argv) != 3:
   print "ex5: this script requires 3 parameters: location of DefaultApplication.ear,"
   print "     node name, and server name."
   print ""
   print "e.g.:     ex5  c:/WebSphere/AppServer/installableApps mynode server1" 
else:
   ex5(sys.argv[0], sys.argv[1], sys.argv[2])
