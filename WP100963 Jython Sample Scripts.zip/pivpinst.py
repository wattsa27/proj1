import sys
#
#  � Copyright IBM Corporation, 2007, 2008
#
#
#  Sample invocation:
#
#  ./wsadmin.sh -lang jython -javaoption -Dscript.encoding=IBM-1047 -f /u/mjloos/tb/pivpinst.py
#
	#
#  Uninstall the app if it is there
#
applist = AdminApp.list().split("\n")
#
for ap in applist:
    if ap == "PolicyIVPV5":
        print "Found and uninstalling ",
        print ap
        am = AdminControl.queryNames('cell=s1cell,node=s1nodec,type=ApplicationManager,process=s1sr01c,*')
        AdminControl.invoke(am, 'stopApplication', 'PolicyIVPV5')
        AdminApp.uninstall(ap)
    continue
#
#  Installing app
#
print "Installing application PolicyIVPV5"
#
#
earfile = "/tmp/PolicyIVPV5.ear"
appopts = "[-appname "
appopts = appopts + "PolicyIVPV5 "
appopts = appopts + "-reloadEnabled -reloadInterval 0 -createMBeansForResources "
appopts = appopts + "-MapModulesToServers [[ PolicyIVPV5CMP PolicyIVPV5CMP.jar,META-INF/ejb-jar.xml "
appopts = appopts + " WebSphere:cell=s1cell,node=s1nodec,server=s1sr01c ] "
appopts = appopts + " [ PolicyIVPV5BMP PolicyIVPV5BMP.jar,META-INF/ejb-jar.xml "
appopts = appopts + " WebSphere:cell=s1cell,node=s1nodec,server=s1sr01c ] "
appopts = appopts + " [ PolicyIVPV5Session  PolicyIVPV5Session.jar,META-INF/ejb-jar.xml "
appopts = appopts + " WebSphere:cell=s1cell,node=s1nodec,server=s1sr01c ] "
appopts = appopts + " [ PolicyIVPV5Web PolicyIVPV5Web.war,WEB-INF/web.xml "
appopts = appopts + " WebSphere:cell=s1cell,node=s1nodec,server=s1sr01c ]] "
appopts = appopts + " -MapResRefToEJB [[ PolicyIVPV5BMP PolicyBMPV5 "
appopts = appopts + " PolicyIVPV5BMP.jar,META-INF/ejb-jar.xml jdbc/policy javax.sql.DataSource "
appopts = appopts + " jdbc/IVPDS ]] " 
appopts = appopts + "  -DataSourceFor20CMPBeans [[ PolicyIVPV5CMP PolicyCMPV5 "
appopts = appopts + " PolicyIVPV5CMP.jar,META-INF/ejb-jar.xml jdbc/IVPDS cmpBinding.perConnectionFactory ]] "
appopts = appopts + "  -DataSourceFor20EJBModules [[ PolicyIVPV5CMP PolicyIVPV5CMP.jar,META-INF/ejb-jar.xml "
appopts = appopts + "  jdbc/IVPDS cmpBinding.perConnectionFactory ]]]"
#
#print "appopts = " + appopts
#
AdminApp.install(earfile, appopts)
#
#
#  Save the config
#
AdminConfig.save()
#
#  Sync the node.
#
nl = AdminConfig.list('Node').split("\n")
for n in nl:
    nn = AdminConfig.showAttribute(n, 'name')
    objn = "type=NodeSync,node=" + nn + ",*"
    Syncl = AdminControl.completeObjectName(objn)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nn
    else:
        print "Skipping node " + nn
    continue
#
#  Start the application
#
am = AdminControl.queryNames('cell=s1cell,node=s1nodec,type=ApplicationManager,process=s1sr01c,*')
AdminControl.invoke(am, 'startApplication', 'PolicyIVPV5')
#  All done!
