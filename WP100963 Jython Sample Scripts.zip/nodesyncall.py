#
#  � Copyright IBM Corporation, 2007, 2008
#
nodelist = AdminConfig.list('Node').split("\n")
for n in nodelist:
    nodename = AdminConfig.showAttribute(n, 'name')
    objname = "type=NodeSync,node=" + nodename + ",*"
    Syncl = AdminControl.completeObjectName(objname)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nodename
    else:
        print "Skipping node " + nodename
    continue


