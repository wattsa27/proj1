import sys
#
#  Sample invocation:
#
#  ./wsadmin.sh -lang jython -javaoption -Dscript.encoding=IBM-1047 -f scriptpath/initsetvars.py 
#
#
#  � Copyright IBM Corporation, 2007, 2008
#
#
#  Set up some variables after initial setup of a cell.  Specifically, delete all occurances of the
#  ras_log_logstreamName variable in all scopes so that the annoying RACF message the log failure message
#  will stop appearing if you haven't actually setup logstreams and add all of the variables necessary
#  to cause the many WTO messages to be re-routed to the DEFALTDD and HRDCPYDD ddnames.  The ddnames
#  need to be added to all of the procs that end in 'Z'.
#
#
#     This variable should be set to the local time zone
#
tzvar = "CST6CDT"
#
#     newline character
#
nl = "\n"          #  newline character
#
#  Get the name of the cell.
#
cells = AdminConfig.list('Cell').split(nl)
cell = cells[0]
cellname = AdminConfig.showAttribute(cell, 'name')
#
#   set up the cellname comparison variable
#
cellvar = "(cells/" + cellname
print 'Cell variable is ',
print cellvar

vlist = AdminConfig.list('VariableMap').split(nl)
for v in vlist:
    vselist = AdminConfig.list('VariableSubstitutionEntry', v).split(nl)
    for vs in vselist:
        if vs != "":
            vslen = len(vs.split("/"))
            if vslen > 3:
                nodename = vs.split("/")[3]
                nodename = nodename.split("|")[0]
            if AdminConfig.showAttribute(vs, 'symbolicName') == 'ras_log_logstreamName':
                rc = AdminConfig.remove(vs)
                print 'Removed ras_log_logstreamName variable from scope ',
                print nodename 
            continue
    continue
sname1 = ['symbolicName', 'DAEMON_ras_default_msg_dd']
value1 = ['value', 'DEFALTDD']
arglist1 = [sname1, value1]
sname2 = ['symbolicName', 'DAEMON_ras_hardcopy_msg_dd']
value2 = ['value', 'HRDCPYDD']
value3 = ['value', '1']
value4 = ['value', tzvar]
arglist2 = [sname2, value2]
sname3 = ['symbolicName', 'ras_default_msg_dd']
arglist3 = [sname3, value1]
sname4 = ['symbolicName', 'ras_hardcopy_msg_dd']
arglist4 = [sname4, value2]
sname5 = ['symbolicName', 'ras_time_local']
arglist5 = [sname5, value3]
sname6 = ['symbolicName', 'TZ']
arglist6 = [sname6, value4]
sname7 = ['symbolicName', 'DAEMON_ras_time_local']
arglist7 = [sname7, value3]
vlist = AdminConfig.list('VariableMap').split(nl)
for v in vlist:
    if v.split('|')[0] == cellvar:
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist1)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist2)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist3)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist4)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist5)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist6)
        rc = AdminConfig.create('VariableSubstitutionEntry', v, arglist7)
        print 'Adding the following variables and values to the cell ',
        print cellname,
        print ' scope:'
        print '    DAEMON_ras_default_msg_dd=DEFALTDD'
        print '    DAEMON_ras_hardcopy_msg_dd=HRDCPYDD'
        print '    ras_default_msg_dd=DEFALTDD'
        print '    ras_hardcopy_msg_dd=HRDCPYDD'
        print '    DAEMON_ras_time_local=1'
        print '    ras_time_local=1'
        print '    TZ=',
        print tzvar
        print ' '
    continue
#  Save the config....
rc = AdminConfig.save()
#  Synch with nodes...
nl = AdminConfig.list('Node').split(nl)
for n in nl:
    nn = AdminConfig.showAttribute(n, 'name')
    objn = "type=NodeSync,node=" + nn + ",*"
    Syncl = AdminControl.completeObjectName(objn)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nn
    else:
        print "Skipping node " + nn
    continue
# All done!     
