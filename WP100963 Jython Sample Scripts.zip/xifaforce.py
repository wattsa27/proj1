 import sys
#
# ./wsadmin.sh -lang jython -javaoption -Dscript.encoding=IBM-1047\
# -user userid -password password -f /scriptingpath/xifaforce.py
#
#
#  � Copyright IBM Corporation, 2007, 2008
#
#   get a list of all of the jvms in the cell
#
jvmlist = AdminConfig.list('JavaVirtualMachine').split("\n")
#
ifaconst = '-Xifa:force'
for jvm in jvmlist:
    print
    print "Modifying JVM ",
    print jvm
    print
    arg1 = 'genericJvmArguments'
    arg2 = AdminConfig.showAttribute(jvm, arg1)
    if not arg2:
        arg2 = ""
    print 'Old generic JVM args = ',
    print arg2
    arg2 = arg2 + " " + ifaconst
    arg2 = arg2.strip()
    print "New generic JVM args = ",
    print arg2
    print
    rc = AdminConfig.modify(jvm, [[arg1, arg2]])
    continue
#
#
#   Save the Config
#
AdminConfig.save()
#
#
#   Synchronize with the nodes...
print "Synchronizing Nodes"
print
#
nl = AdminConfig.list('Node').split("\n")
#
#
for n in nl:
    nn = AdminConfig.showAttribute(n, 'name')
    objn = "type=NodeSync,node=" + nn + ",*"
    Syncl = AdminControl.completeObjectName(objn)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nn
    else:
        print "Skipping node " + nn
    continue
#  All Done.
