import sys
#
#  Sample invocation:
#
#  ./wsadmin.sh -lang jython -javaoption -Dscript.encoding=IBM-1047 -f /u/mjloos/tb/reloadintv.py
#
#
#  � Copyright IBM Corporation, 2007, 2008
#
#
#  Get a list of all of the apps, then edit them to add -reloadenabled and -reloadinterval 0 options.
#
appopts = "[-reloadEnabled -reloadInterval 0]"
applist = AdminApp.list().split("\n")
#
for ap in applist:
    print "Found and modifying ",
    print ap
    AdminApp.edit(ap, appopts)
    continue
#
#  Save the config
#
AdminConfig.save()
#
#  Synchronize the nodes
#
nl = AdminConfig.list('Node').split("\n")
for n in nl:
    nn = AdminConfig.showAttribute(n, 'name')
    objn = "type=NodeSync,node=" + nn + ",*"
    Syncl = AdminControl.completeObjectName(objn)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nn
    else:
        print "Skipping node " + nn
    continue
# All done!
