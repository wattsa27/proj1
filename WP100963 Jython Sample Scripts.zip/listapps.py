#
#  � Copyright IBM Corporation, 2007, 2008
#
applist = AdminApp.list().split("\n")
for a in applist:
    print a
    continue
