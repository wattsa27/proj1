import sys
#
# ./wsadmin.sh -lang jython -javaoption -Dscript.encoding=IBM-1047\
# -user userid -password password -f /scriptingpath/remxifaforce.py
#
#
#  � Copyright IBM Corporation, 2007, 2008
#
#   get a list of all of the jvms in the cell
#
jvmlist = AdminConfig.list('JavaVirtualMachine').split("\n")
#
ifaconst = '-Xifa:force'
for jvm in jvmlist:
    print
    print "Modifying JVM ",
    print jvm
    print
    argm = ""
    arg1 = 'genericJvmArguments'
    arg2 = AdminConfig.showAttribute(jvm, arg1).split(" ")
    print 'Old Generic JVM args = ',
    print arg2
    for a in arg2:
        if a != ifaconst:
          argm = argm + " " + a
        continue
    argm = argm.strip()
    print 'New Generic JVM args = ',
    print argm
    rc = AdminConfig.modify(jvm, [[arg1, argm]])
    continue
#
#
#   Save the Config
#
AdminConfig.save()
#
#
#   Synchronize with the nodes...
print "Synchronizing Nodes"
print
#
nl = AdminConfig.list('Node').split("\n")
#
#
for n in nl:
    nn = AdminConfig.showAttribute(n, 'name')
    objn = "type=NodeSync,node=" + nn + ",*"
    Syncl = AdminControl.completeObjectName(objn)
    if Syncl != "":
        AdminControl.invoke(Syncl, 'sync')
        print "Done with node " + nn
    else:
        print "Skipping node " + nn
    continue
#  All Done.

