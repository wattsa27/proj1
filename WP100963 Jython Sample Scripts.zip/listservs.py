import sys
#
#
#  � Copyright IBM Corporation, 2007, 2008
#
#
n1 = sys.argv[0]
#
#
plist = "[-serverType APPLICATION_SERVER -nodeName " + n1 + "]"
print plist
#
slist = AdminTask.listServers(plist).split("\n")
#
for s in slist:
  print s
  continue
